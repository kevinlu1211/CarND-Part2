/*
 * particle_filter.cpp
 *
 *  Created on: Dec 12, 2016
 *      Author: Tiffany Huang
 */

#include <random>
#include <algorithm>
#include <iostream>
#include <numeric>

#include "particle_filter.h"
using namespace std;

void ParticleFilter::init(double x, double y, double theta, double std[]) {
	// TODO: Set the number of particles. Initialize all particles to first position (based on estimates of 
	//   x, y, theta and their uncertainties from GPS) and all weights to 1. 
	// Add random Gaussian noise to each particle.
	// NOTE: Consult particle_filter.h for more information about this method (and others in this file).
    num_particles = 15;
    std::default_random_engine gen;
    
    weights.resize(num_particles);
    
    std::normal_distribution<double> dist_x(x, std[0]);
    std::normal_distribution<double> dist_y(y, std[1]);
    std::normal_distribution<double> dist_theta(theta, std[2]);
    
    for (int i = 0; i < num_particles; i++) {
        Particle particle;
        particle.id = i;
        particle.x = dist_x(gen);
        particle.y = dist_y(gen);
        particle.theta = dist_theta(gen);
        particle.weight = 1.0;
        particles.push_back(particle);
    }
    
    is_initialized = true;
    
    for (Particle particle: particles) {
        std::cout << particle.x << std::endl;
    }

}

void ParticleFilter::prediction(double delta_t, double std_pos[], double velocity, double yaw_rate) {
	// TODO: Add measurements to each particle and add random Gaussian noise.
	// NOTE: When adding noise you may find std::normal_distribution and std::default_random_engine useful.
	//  http://en.cppreference.com/w/cpp/numeric/random/normal_distribution
	//  http://www.cplusplus.com/reference/random/default_random_engine/
    std::default_random_engine gen;
    std::normal_distribution<double> noise_x(0.0, std_pos[0]);
    std::normal_distribution<double> noise_y(0.0, std_pos[1]);
    std::normal_distribution<double> noise_theta(0.0, std_pos[2]);
    
    // NEED TO ADD THE POINTER TO CHANGE THE VARIABLE!!!!
    for (Particle &particle: particles) {
        if (fabs(yaw_rate) > 0.00001) {
            particle.x = particle.x + (velocity/yaw_rate) * (sin(particle.theta + yaw_rate * delta_t) - sin(particle.theta)) + noise_x(gen);
            particle.y = particle.y + (velocity/yaw_rate) * (cos(particle.theta) - cos(particle.theta + yaw_rate * delta_t)) + noise_y(gen);
        } else {
            particle.x = particle.x + velocity * delta_t * cos(particle.theta) + noise_x(gen);
            particle.y = particle.y + velocity * delta_t * sin(particle.theta) + noise_y(gen);
        }
        particle.theta = particle.theta + yaw_rate * delta_t + noise_theta(gen);
    }

    // for (Particle particle: particles) {
    //     std::cout << particle.x << std::endl;
    // }

}


void ParticleFilter::updateWeights(double sensor_range, double std_landmark[], 
		std::vector<LandmarkObs> observations, Map map_landmarks) {
	// TODO: Update the weights of each particle using a mult-variate Gaussian distribution. You can read
	//   more about this distribution here: https://en.wikipedia.org/wiki/Multivariate_normal_distribution
	// NOTE: The observations are given in the VEHICLE'S coordinate system. Your particles are located
	//   according to the MAP'S coordinate system. You will need to transform between the two systems.
	//   Keep in mind that this transformation requires both rotation AND translation (but no scaling).
	//   The following is a good resource for the theory:
	//   https://www.willamette.edu/~gorr/classes/GeneralGraphics/Transforms/transforms2d.htm
	//   and the following is a good resource for the actual equation to implement (look at equation 
	//   3.33. Note that you'll need to switch the minus sign in that equation to a plus to account 
	//   for the fact that the map's y-axis actually points downwards.)
	//   http://planning.cs.uiuc.edu/node99.html
    
    // make code easier to read. used to calculate new weights.
    double var_x = pow(std_landmark[0], 2);
    double var_y = pow(std_landmark[1], 2);
    double covar_xy = std_landmark[0] * std_landmark[1];
    double weights_sum = 0;
    
    for (int i=0; i < num_particles; i++) {
        // predict measurements to all map landmarks
        Particle& particle = particles[i];
        
        // setup weight
        long double weight = 1;
        
        for (int j=0; j < observations.size(); j++) {
            // transform vehicle's observation to global coordinates
            LandmarkObs obs = observations[j];
            
            double predicted_x = obs.x * cos(particle.theta) - obs.y * sin(particle.theta) + particle.x;
            double predicted_y = obs.x * sin(particle.theta) + obs.y * cos(particle.theta) + particle.y;
            
            // initialise terms
            Map::single_landmark_s nearest_landmark;
            double min_distance = sensor_range;
            double distance = 0;
            
            // now that we have the observations in the coordinates as the GPS coordinates
            // find the landmark that is closest to our observation
            for (int k = 0; k < map_landmarks.landmark_list.size(); k++) {
                
                Map::single_landmark_s landmark = map_landmarks.landmark_list[k];
                
                // calculate distance using manhanttan distance
                distance = fabs(predicted_x - landmark.x_f) + fabs(predicted_y - landmark.y_f);
                
                // update nearest landmark to obs
                if (distance < min_distance) {
                    min_distance = distance;
                    nearest_landmark = landmark;
                }
                
                
            } // end associate nearest landmark
            
            // Use bivariate Gaussian to calculate probabilities
            double x_diff = predicted_x - nearest_landmark.x_f;
            double y_diff = predicted_y - nearest_landmark.y_f;
            double num = exp(-0.5*((x_diff * x_diff)/var_x + (y_diff * y_diff)/var_y));
            double denom = 2*M_PI*covar_xy;
            double prob = num/denom;
            
            // std::cout << "prob: " << prob << std::endl;
            // multiply particle weight by this obs-weight pair stat
            weight *= prob;
            
        } // end observations loop
         
        
        
        particle.weight = weight;
        weights[i] = weight;
        weights_sum += weight;
        
    }
    // for (double weight : weights) {
    //     // std::cout << "weight: " << weight << std::endl;
    // }
}

void ParticleFilter::resample() {
	// TODO: Resample particles with replacement with probability proportional to their weight. 
	// NOTE: You may find std::discrete_distribution helpful here.
	//   http://en.cppreference.com/w/cpp/numeric/random/discrete_distribution
    
    std::default_random_engine gen;
    
    // Take a discrete distribution with pmf equal to weights
    std::discrete_distribution<> weights_pmf(weights.begin(), weights.end());
    // initialise new particle array
    std::vector<Particle> sampled_particles;
    // resample particles
    for (int i = 0; i < num_particles; ++i)
        sampled_particles.push_back(particles[weights_pmf(gen)]);
    
    particles = sampled_particles;

}

void ParticleFilter::write(std::string filename) {
	// You don't need to modify this file.
	std::ofstream dataFile;
	dataFile.open(filename, std::ios::app);
	for (int i = 0; i < num_particles; ++i) {
		dataFile << particles[i].x << " " << particles[i].y << " " << particles[i].theta << "\n";
	}
	dataFile.close();
}

