#!/bin/sh
make -C /Users/kevinlu/Documents/Udacity-Self-Driving-CarND/Part\ 2/CarND-Extended-Kalman-Filter-Project/ide_profiles/xcode -f /Users/kevinlu/Documents/Udacity-Self-Driving-CarND/Part\ 2/CarND-Extended-Kalman-Filter-Project/ide_profiles/xcode/CMakeScripts/ZERO_CHECK_cmakeRulesBuildPhase.make$CONFIGURATION all
